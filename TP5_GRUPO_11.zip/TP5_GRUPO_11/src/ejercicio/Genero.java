package ejercicio;

public class Genero {
	
	private String genero;

public Genero(String genero) {
	this.genero = genero;
}

@Override
public String toString() {
	return ""+ genero;
}
	
	
}
